package com.zatackcoder.filtersortexample;

import com.zatackcoder.filtersortexample.classes.Filter;

import java.util.HashMap;

public abstract class Preferences {
    public  static HashMap<Integer, Filter> filters = new HashMap<>();
}
